package com.example.f2cfarmer.models

data class ProductsModel(
    var prdId : String? = null,
    var prdName : String? = null,
    var prdPrice : String? = null,
    var prdQuantity : String? = null

)
